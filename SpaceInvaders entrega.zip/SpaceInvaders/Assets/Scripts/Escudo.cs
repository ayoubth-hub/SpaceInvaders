using UnityEngine;

/// <summary>
/// Escudo (búnker). Cada impacto lo oscurece y, tras varios, se destruye.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class Escudo : MonoBehaviour
{
    public int resistencia = 8;
    public Color colorDanado = new Color(0.3f, 0.3f, 0.3f);

    private int vidaActual;
    private SpriteRenderer sr;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        vidaActual = resistencia;
    }

    /// <summary>Lo llaman tanto la bala del jugador como los misiles de los aliens.</summary>
    public void RecibirImpacto()
    {
        vidaActual--;
        if (vidaActual <= 0)
        {
            Destroy(gameObject);
            return;
        }

        // Cuanta menos vida, más oscuro
        sr.color = Color.Lerp(colorDanado, Color.white, (float)vidaActual / resistencia);
    }
}

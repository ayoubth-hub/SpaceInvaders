using UnityEngine;

/// <summary>
/// Bala que dispara el jugador. Sube en línea recta y usa un collider de tipo
/// Trigger, así que detectamos los impactos con OnTriggerEnter2D.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class BalaJugador : MonoBehaviour
{
    public float velocidad = 12f;

    private bool usada; // evita que una misma bala destruya dos cosas en el mismo fotograma

    void Start()
    {
        // Rigidbody2D dinámico sin gravedad: le damos velocidad hacia arriba y se mueve sola
        GetComponent<Rigidbody2D>().linearVelocity = Vector2.up * velocidad;
    }

    void Update()
    {
        // Si sale por arriba de la pantalla, la destruimos (y el jugador puede volver a disparar)
        if (transform.position.y > Limites.MitadAlto + 0.5f)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D otro)
    {
        if (usada) return;

        if (otro.TryGetComponent(out Alien alien))
        {
            alien.Morir();
            Impactar();
        }
        else if (otro.TryGetComponent(out Ufo ufo))
        {
            ufo.Destruir();
            Impactar();
        }
        else if (otro.TryGetComponent(out Escudo escudo))
        {
            escudo.RecibirImpacto();
            Impactar();
        }
        else if (otro.TryGetComponent(out MisilAlien misil))
        {
            // Bala contra misil: se anulan los dos
            Destroy(misil.gameObject);
            Impactar();
        }
    }

    private void Impactar()
    {
        usada = true;
        Destroy(gameObject);
    }
}

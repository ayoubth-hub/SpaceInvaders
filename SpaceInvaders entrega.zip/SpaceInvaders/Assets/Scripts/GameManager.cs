using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Controla la partida: puntos, vidas, interfaz y fin de partida (GAME OVER o VICTORIA).
/// Hay uno solo en la escena y el resto de scripts lo usan con GameManager.Instancia.
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instancia { get; private set; }

    public int vidasIniciales = 3;

    [Header("Interfaz")]
    public Text textoPuntos;
    public Text textoVidas;
    public GameObject panelFin;
    public Text textoTituloFin;
    public Text textoResumenFin;

    public int Puntos { get; private set; }
    public int Vidas { get; private set; }
    public bool PartidaTerminada { get; private set; }

    private const string ClaveRecord = "Record";

    void Awake()
    {
        Instancia = this;
        Time.timeScale = 1f;
    }

    void OnEnable() { Alien.AlienDestruido += AlMorirAlien; }
    void OnDisable() { Alien.AlienDestruido -= AlMorirAlien; }

    void Start()
    {
        Vidas = vidasIniciales;
        Puntos = 0;
        if (panelFin != null) panelFin.SetActive(false);
        ActualizarInterfaz();
    }

    void Update()
    {
        // Con la partida terminada, ENTER vuelve a empezar
        if (PartidaTerminada && Entrada.Confirmar())
        {
            Reiniciar();
        }
    }

    private void AlMorirAlien(Alien alien)
    {
        SumarPuntos(alien.puntos);
    }

    public void SumarPuntos(int cantidad)
    {
        if (PartidaTerminada) return;
        Puntos += cantidad;
        ActualizarInterfaz();
    }

    public void PerderVida()
    {
        if (PartidaTerminada) return;
        Vidas = Mathf.Max(0, Vidas - 1);
        ActualizarInterfaz();

        if (Vidas == 0)
        {
            // Esperamos un poco para que se vea la explosión de la nave
            Invoke(nameof(GameOverSinVidas), 1.2f);
        }
    }

    private void GameOverSinVidas()
    {
        GameOver("TE HAS QUEDADO SIN VIDAS");
    }

    public void GameOver(string motivo)
    {
        TerminarPartida("GAME OVER", Color.red, motivo);
    }

    public void Victoria()
    {
        TerminarPartida("¡VICTORIA!", Color.green, "HAS ELIMINADO A TODOS LOS ALIENS");
    }

    private void TerminarPartida(string titulo, Color color, string motivo)
    {
        if (PartidaTerminada) return;
        PartidaTerminada = true;

        // Guardamos el récord
        int record = PlayerPrefs.GetInt(ClaveRecord, 0);
        if (Puntos > record)
        {
            record = Puntos;
            PlayerPrefs.SetInt(ClaveRecord, record);
            PlayerPrefs.Save();
        }

        if (panelFin != null)
        {
            panelFin.SetActive(true);
            textoTituloFin.text = titulo;
            textoTituloFin.color = color;
            textoResumenFin.text = motivo + "\n\nPUNTOS: " + Puntos.ToString("0000") +
                                   "\nRÉCORD: " + record.ToString("0000") +
                                   "\n\nPulsa ENTER para volver a jugar";
        }

        // Congelamos el juego
        Time.timeScale = 0f;
    }

    private void ActualizarInterfaz()
    {
        if (textoPuntos != null) textoPuntos.text = "PUNTOS: " + Puntos.ToString("0000");
        if (textoVidas != null) textoVidas.text = "VIDAS: " + Vidas;
    }

    // ---- Botones del panel de fin de partida ----

    public void Reiniciar()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void IrAlMenu()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene("Menu");
    }
}

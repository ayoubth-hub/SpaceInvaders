using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Crea la formación de aliens y la mueve toda junta de lado a lado.
/// Al tocar un borde baja una fila y cambia de dirección.
/// Cuantos menos aliens quedan (o más abajo están), más rápido se mueven y más disparan.
/// </summary>
public class Enjambre : MonoBehaviour
{
    [Header("Prefabs de los aliens")]
    public Alien prefabAlienA;   // filas de abajo (10 pts)
    public Alien prefabAlienB;   // filas del medio (20 pts)
    public Alien prefabAlienC;   // fila de arriba (30 pts)

    [Header("Formación")]
    public int columnas = 7;
    public int filas = 5;
    [Tooltip("Cuántas filas de tipo B hay debajo de la fila de tipo C")]
    public int filasTipoB = 1;
    public float separacionX = 1f;
    [Tooltip("Distancia entre filas. Es también lo que baja el enjambre al tocar un borde (UNA fila)")]
    public float separacionY = 0.6f;

    [Header("Movimiento")]
    public float pasoHorizontal = 0.2f;   // cuánto avanza en cada paso
    public float intervaloInicial = 0.4f; // segundos entre pasos con todos los aliens vivos
    public float intervaloMinimo = 0.03f; // segundos entre pasos cuando queda uno solo

    [Header("Disparo")]
    public float tiempoEntreDisparosInicial = 1.5f;
    public float tiempoEntreDisparosMinimo = 0.3f;
    public int maxMisilesEnPantalla = 3;

    [Header("Fin de partida")]
    [Tooltip("Altura de los escudos: si un alien llega aquí, GAME OVER")]
    public float limiteInferior = -1.9f;
    public Jugador jugador;

    private readonly List<Alien> aliens = new List<Alien>();
    private int totalAliens;
    private int direccion = 1;          // 1 = derecha, -1 = izquierda
    private float temporizadorPaso;
    private float temporizadorDisparo;
    private float alturaInicial;

    void OnEnable() { Alien.AlienDestruido += AlienEliminado; }
    void OnDisable() { Alien.AlienDestruido -= AlienEliminado; }

    void Start()
    {
        CrearFormacion();
        totalAliens = aliens.Count;
        alturaInicial = transform.position.y;
        temporizadorDisparo = tiempoEntreDisparosInicial;
    }

    /// <summary>Instancia la cuadrícula de aliens como hijos de este objeto.</summary>
    private void CrearFormacion()
    {
        for (int fila = 0; fila < filas; fila++)
        {
            Alien prefab;
            if (fila == 0) prefab = prefabAlienC;            // arriba: tipo C
            else if (fila <= filasTipoB) prefab = prefabAlienB;
            else prefab = prefabAlienA;                      // abajo: tipo A

            for (int col = 0; col < columnas; col++)
            {
                Alien alien = Instantiate(prefab, transform);
                float x = (col - (columnas - 1) / 2f) * separacionX;
                float y = -fila * separacionY;
                alien.transform.localPosition = new Vector3(x, y, 0f);
                alien.columna = col;
                alien.name = prefab.name + "_" + fila + "_" + col;
                aliens.Add(alien);
            }
        }
    }

    void Update()
    {
        if (GameManager.Instancia.PartidaTerminada) return;

        // VICTORIA: no queda ningún alien
        // (se comprueba aquí y no en AlienEliminado para que antes se sumen los puntos del último alien)
        if (aliens.Count == 0)
        {
            GameManager.Instancia.Victoria();
            return;
        }

        // Movimiento por pasos, como en el arcade
        temporizadorPaso += Time.deltaTime;
        if (temporizadorPaso >= IntervaloActual())
        {
            temporizadorPaso = 0f;
            DarPaso();
        }

        // Disparo aleatorio (no disparan mientras la nave está explotando)
        if (jugador == null || jugador.EstaActivo)
        {
            temporizadorDisparo -= Time.deltaTime;
            if (temporizadorDisparo <= 0f)
            {
                Disparar();
                temporizadorDisparo = TiempoSiguienteDisparo();
            }
        }
    }

    /// <summary>Fracción de aliens que siguen vivos: 1 al principio, casi 0 al final.</summary>
    private float FraccionRestante
    {
        get { return (float)aliens.Count / totalAliens; }
    }

    /// <summary>Tiempo entre pasos. Baja con menos aliens y también al acercarse al jugador.</summary>
    private float IntervaloActual()
    {
        float intervalo = Mathf.Lerp(intervaloMinimo, intervaloInicial, FraccionRestante);

        // 0 = arriba del todo, 1 = a la altura de los escudos
        float progresoBajada = Mathf.InverseLerp(alturaInicial, limiteInferior, transform.position.y);
        intervalo *= Mathf.Lerp(1f, 0.6f, progresoBajada);

        return intervalo;
    }

    private void DarPaso()
    {
        // ¿Algún alien se saldría por el borde si avanzamos?
        float limite = Limites.X;
        bool tocaBorde = false;
        foreach (Alien alien in aliens)
        {
            float bordeAlien = alien.transform.position.x + direccion * (alien.MitadAncho + pasoHorizontal);
            if ((direccion > 0 && bordeAlien > limite) || (direccion < 0 && bordeAlien < -limite))
            {
                tocaBorde = true;
                break;
            }
        }

        if (tocaBorde)
        {
            // Bajamos UNA fila (la misma distancia que separa las filas) y cambiamos de dirección
            transform.position += Vector3.down * separacionY;
            direccion = -direccion;
        }
        else
        {
            transform.position += Vector3.right * direccion * pasoHorizontal;
        }

        // Animación: todos cambian de frame a la vez
        foreach (Alien alien in aliens)
        {
            alien.CambiarFrame();
        }

        // ¿Han llegado a los escudos?
        if (YAlienMasBajo() <= limiteInferior)
        {
            GameManager.Instancia.GameOver("¡HAN INVADIDO LA TIERRA!");
        }
    }

    /// <summary>Altura del borde inferior del alien más bajo.</summary>
    private float YAlienMasBajo()
    {
        float minimo = float.MaxValue;
        foreach (Alien alien in aliens)
        {
            float y = alien.transform.position.y - alien.MitadAlto;
            if (y < minimo) minimo = y;
        }
        return minimo;
    }

    /// <summary>Elige una columna al azar y dispara el alien más bajo de esa columna.</summary>
    private void Disparar()
    {
        if (MisilAlien.Activos >= maxMisilesEnPantalla) return;

        Alien elegido = aliens[Random.Range(0, aliens.Count)];
        Alien tirador = elegido;
        foreach (Alien alien in aliens)
        {
            if (alien.columna == elegido.columna && alien.transform.position.y < tirador.transform.position.y)
            {
                tirador = alien;
            }
        }
        tirador.Disparar();
    }

    /// <summary>Cuantos menos aliens, más frecuente es el disparo (con algo de azar).</summary>
    private float TiempoSiguienteDisparo()
    {
        float baseTiempo = Mathf.Lerp(tiempoEntreDisparosMinimo, tiempoEntreDisparosInicial, FraccionRestante);
        return baseTiempo * Random.Range(0.5f, 1.5f);
    }

    /// <summary>Se ejecuta cada vez que muere un alien (evento Alien.AlienDestruido).</summary>
    private void AlienEliminado(Alien alien)
    {
        aliens.Remove(alien);
    }
}

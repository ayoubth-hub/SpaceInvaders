using System.Collections;
using UnityEngine;

/// <summary>
/// Nave del jugador: se mueve en horizontal (flechas o A/D), dispara con ESPACIO
/// y, cuando la alcanza un misil, explota y reaparece tras unos segundos.
/// </summary>
[RequireComponent(typeof(SpriteRenderer), typeof(Collider2D))]
public class Jugador : MonoBehaviour
{
    [Header("Movimiento")]
    public float velocidad = 6f;

    [Header("Disparo")]
    public BalaJugador prefabBala;
    public Vector3 desplazamientoDisparo = new Vector3(0f, 0.35f, 0f);

    [Header("Muerte y reaparición")]
    public Sprite spriteExplosion;
    public float duracionExplosion = 1f;     // tiempo que parpadea la explosión
    public float tiempoReaparicion = 1f;     // espera extra antes de volver a aparecer
    public float tiempoInvencible = 1.5f;    // parpadeo tras reaparecer, sin recibir daño

    /// <summary>False mientras la nave está explotando o esperando para reaparecer.</summary>
    public bool EstaActivo { get; private set; } = true;

    private SpriteRenderer sr;
    private Collider2D col;
    private Sprite spriteNormal;
    private Vector3 posicionInicial;
    private BalaJugador balaActual;   // solo se permite una bala en pantalla, como en el arcade
    private bool invencible;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        col = GetComponent<Collider2D>();
        spriteNormal = sr.sprite;
    }

    void Start()
    {
        posicionInicial = transform.position;
    }

    void Update()
    {
        if (!EstaActivo || GameManager.Instancia.PartidaTerminada) return;

        // Movimiento horizontal
        float h = Entrada.Horizontal();
        Vector3 pos = transform.position + Vector3.right * h * velocidad * Time.deltaTime;

        // No dejamos que la nave se salga de la pantalla
        float limite = Limites.X - sr.bounds.extents.x;
        pos.x = Mathf.Clamp(pos.x, -limite, limite);
        transform.position = pos;

        // Disparo: solo si no hay otra bala nuestra en pantalla
        if (Entrada.Disparar() && balaActual == null)
        {
            balaActual = Instantiate(prefabBala, transform.position + desplazamientoDisparo, Quaternion.identity);
        }
    }

    /// <summary>Lo llama el misil enemigo al chocar con la nave.</summary>
    public void Alcanzado()
    {
        if (!EstaActivo || invencible) return;
        StartCoroutine(MorirYReaparecer());
    }

    private IEnumerator MorirYReaparecer()
    {
        EstaActivo = false;
        col.enabled = false;
        GameManager.Instancia.PerderVida();

        // Quitamos los misiles enemigos que haya en pantalla para que la reaparición sea justa
        foreach (MisilAlien misil in FindObjectsByType<MisilAlien>(FindObjectsSortMode.None))
        {
            Destroy(misil.gameObject);
        }

        // Animación de explosión: cambiamos el sprite y lo hacemos parpadear
        sr.sprite = spriteExplosion;
        float t = 0f;
        while (t < duracionExplosion)
        {
            sr.enabled = !sr.enabled;
            yield return new WaitForSeconds(0.1f);
            t += 0.1f;
        }
        sr.enabled = false;

        // Si no quedan vidas no reaparecemos (el GameManager mostrará GAME OVER)
        if (GameManager.Instancia.Vidas <= 0) yield break;

        yield return new WaitForSeconds(tiempoReaparicion);

        // Reaparecemos en la posición inicial
        transform.position = posicionInicial;
        sr.sprite = spriteNormal;
        sr.enabled = true;
        col.enabled = true;
        EstaActivo = true;

        // Unos segundos de invencibilidad con parpadeo
        invencible = true;
        t = 0f;
        while (t < tiempoInvencible)
        {
            sr.enabled = !sr.enabled;
            yield return new WaitForSeconds(0.1f);
            t += 0.1f;
        }
        sr.enabled = true;
        invencible = false;
    }
}

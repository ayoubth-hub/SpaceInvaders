using UnityEngine;

/// <summary>
/// Misil que disparan los aliens. Baja en línea recta, anima sus 4 sprites
/// y usa un collider normal (no Trigger), así que los choques llegan por OnCollisionEnter2D.
/// </summary>
[RequireComponent(typeof(Rigidbody2D), typeof(SpriteRenderer))]
public class MisilAlien : MonoBehaviour
{
    /// <summary>Cuántos misiles enemigos hay ahora mismo en pantalla.</summary>
    public static int Activos { get; private set; }

    public float velocidad = 5f;
    public Sprite[] frames;              // sprites de la animación del misil
    public float tiempoPorFrame = 0.08f;

    private SpriteRenderer sr;
    private int frameActual;
    private float temporizador;
    private bool usado;

    void OnEnable() { Activos++; }
    void OnDisable() { Activos--; }

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        GetComponent<Rigidbody2D>().linearVelocity = Vector2.down * velocidad;
    }

    void Update()
    {
        // Animación: pasamos al siguiente sprite cada cierto tiempo
        if (frames != null && frames.Length > 1)
        {
            temporizador += Time.deltaTime;
            if (temporizador >= tiempoPorFrame)
            {
                temporizador = 0f;
                frameActual = (frameActual + 1) % frames.Length;
                sr.sprite = frames[frameActual];
            }
        }

        // Si sale por abajo de la pantalla, lo destruimos
        if (transform.position.y < -Limites.MitadAlto - 0.5f)
        {
            Destroy(gameObject);
        }
    }

    void OnCollisionEnter2D(Collision2D choque)
    {
        if (usado) return;
        usado = true;

        if (choque.collider.TryGetComponent(out Jugador jugador))
        {
            jugador.Alcanzado();
        }
        else if (choque.collider.TryGetComponent(out Escudo escudo))
        {
            escudo.RecibirImpacto();
        }

        // Choque con lo que sea (jugador, escudo, otro misil...): el misil desaparece
        Destroy(gameObject);
    }
}

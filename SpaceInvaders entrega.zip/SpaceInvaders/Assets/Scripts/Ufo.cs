using UnityEngine;

/// <summary>
/// Nave bonus. Cruza la parte de arriba de la pantalla y, si la derribas, da 300 puntos.
/// </summary>
[RequireComponent(typeof(SpriteRenderer), typeof(Collider2D))]
public class Ufo : MonoBehaviour
{
    public float velocidad = 2.5f;
    public int puntos = 300;
    public Sprite spriteExplosion;

    /// <summary>1 = de izquierda a derecha, -1 = de derecha a izquierda (lo pone el generador).</summary>
    [HideInInspector] public int direccion = 1;

    private bool destruido;

    void Update()
    {
        if (destruido || GameManager.Instancia.PartidaTerminada) return;

        transform.position += Vector3.right * direccion * velocidad * Time.deltaTime;

        // Cuando sale por el otro lado, desaparece
        if (Mathf.Abs(transform.position.x) > Limites.MitadAncho + 1.5f)
        {
            Destroy(gameObject);
        }
    }

    /// <summary>Lo llama la bala del jugador.</summary>
    public void Destruir()
    {
        if (destruido) return;
        destruido = true;

        GameManager.Instancia.SumarPuntos(puntos);
        GetComponent<SpriteRenderer>().sprite = spriteExplosion;
        GetComponent<Collider2D>().enabled = false;
        Destroy(gameObject, 0.5f);
    }
}

using System;
using UnityEngine;

/// <summary>Tipos de alien. C es el de la fila de arriba (el que más puntos da).</summary>
public enum TipoAlien { A, B, C }

/// <summary>
/// Un alien del enjambre. Alterna entre sus 2 sprites a cada paso,
/// puede disparar un misil y avisa con un evento cuando muere.
/// </summary>
[RequireComponent(typeof(SpriteRenderer))]
public class Alien : MonoBehaviour
{
    /// <summary>
    /// Evento estático: se lanza cuando muere cualquier alien.
    /// Lo escuchan el GameManager (para sumar puntos) y el Enjambre (para acelerar y detectar la victoria).
    /// </summary>
    public static event Action<Alien> AlienDestruido;

    public TipoAlien tipo = TipoAlien.A;
    public int puntos = 10;

    [Header("Animación (2 frames)")]
    public Sprite frame1;
    public Sprite frame2;

    [Header("Prefabs")]
    public GameObject prefabExplosion;
    public MisilAlien prefabMisil;

    /// <summary>Columna que ocupa en la formación (la asigna el Enjambre).</summary>
    [HideInInspector] public int columna;

    private SpriteRenderer sr;
    private bool usandoFrame2;
    private bool muerto;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        sr.sprite = frame1;
    }

    /// <summary>Mitad del ancho del sprite en el mundo (para saber cuándo toca el borde).</summary>
    public float MitadAncho { get { return sr.bounds.extents.x; } }

    /// <summary>Mitad del alto del sprite en el mundo.</summary>
    public float MitadAlto { get { return sr.bounds.extents.y; } }

    /// <summary>Cambia entre frame 1 y frame 2. El Enjambre lo llama en cada paso.</summary>
    public void CambiarFrame()
    {
        usandoFrame2 = !usandoFrame2;
        sr.sprite = usandoFrame2 ? frame2 : frame1;
    }

    /// <summary>Crea un misil justo debajo del alien.</summary>
    public void Disparar()
    {
        Vector3 posicion = transform.position + Vector3.down * (MitadAlto + 0.2f);
        Instantiate(prefabMisil, posicion, Quaternion.identity);
    }

    /// <summary>Lo llama la bala del jugador al impactar.</summary>
    public void Morir()
    {
        if (muerto) return;
        muerto = true;

        if (prefabExplosion != null)
        {
            Instantiate(prefabExplosion, transform.position, Quaternion.identity);
        }

        AlienDestruido?.Invoke(this);
        Destroy(gameObject);
    }
}

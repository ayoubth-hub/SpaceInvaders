using UnityEngine;

/// <summary>
/// Hace aparecer el UFO de vez en cuando por un lado de la pantalla.
/// </summary>
public class GeneradorUfo : MonoBehaviour
{
    public Ufo prefabUfo;
    public float tiempoMinimo = 15f;
    public float tiempoMaximo = 30f;
    public float altura = 4.35f;

    private float temporizador;
    private Ufo ufoActual;

    void Start()
    {
        temporizador = Random.Range(tiempoMinimo, tiempoMaximo);
    }

    void Update()
    {
        if (GameManager.Instancia.PartidaTerminada) return;
        if (ufoActual != null) return; // solo un UFO a la vez

        temporizador -= Time.deltaTime;
        if (temporizador <= 0f)
        {
            // Sale por la izquierda o por la derecha al azar
            int direccion = Random.value < 0.5f ? 1 : -1;
            Vector3 posicion = new Vector3(-direccion * (Limites.MitadAncho + 1f), altura, 0f);

            ufoActual = Instantiate(prefabUfo, posicion, Quaternion.identity);
            ufoActual.direccion = direccion;

            temporizador = Random.Range(tiempoMinimo, tiempoMaximo);
        }
    }
}

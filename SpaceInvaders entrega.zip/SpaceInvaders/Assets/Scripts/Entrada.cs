using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Agrupa la lectura del teclado en un solo sitio.
/// Funciona tanto con el Input Manager clásico como con el nuevo Input System,
/// así el proyecto compila sea cual sea la opción de "Active Input Handling".
/// </summary>
public static class Entrada
{
    /// <summary>Devuelve -1 (izquierda), 0 (quieto) o 1 (derecha). Flechas o A/D.</summary>
    public static float Horizontal()
    {
        float h = 0f;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        Keyboard teclado = Keyboard.current;
        if (teclado == null) return 0f;
        if (teclado.leftArrowKey.isPressed || teclado.aKey.isPressed) h -= 1f;
        if (teclado.rightArrowKey.isPressed || teclado.dKey.isPressed) h += 1f;
#else
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) h -= 1f;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) h += 1f;
#endif
        return h;
    }

    /// <summary>True solo en el fotograma en que se pulsa ESPACIO.</summary>
    public static bool Disparar()
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        return Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.Space);
#endif
    }

    /// <summary>True en el fotograma en que se pulsa ENTER (para empezar o reintentar).</summary>
    public static bool Confirmar()
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        return Keyboard.current != null &&
               (Keyboard.current.enterKey.wasPressedThisFrame || Keyboard.current.numpadEnterKey.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter);
#endif
    }
}

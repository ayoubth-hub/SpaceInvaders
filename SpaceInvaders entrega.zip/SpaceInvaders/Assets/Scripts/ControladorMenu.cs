using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Script de la escena Menu: el botón JUGAR (o la tecla ENTER) carga la partida.
/// </summary>
public class ControladorMenu : MonoBehaviour
{
    public string escenaJuego = "SpaceInvaders";

    void Start()
    {
        Time.timeScale = 1f;
    }

    void Update()
    {
        if (Entrada.Confirmar())
        {
            Jugar();
        }
    }

    public void Jugar()
    {
        SceneManager.LoadScene(escenaJuego);
    }

    public void Salir()
    {
        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }
}

using UnityEngine;

/// <summary>
/// Efecto de explosión de un alien: se muestra un instante y se destruye solo.
/// </summary>
public class Explosion : MonoBehaviour
{
    public float duracion = 0.25f;

    void Start()
    {
        Destroy(gameObject, duracion);
    }
}

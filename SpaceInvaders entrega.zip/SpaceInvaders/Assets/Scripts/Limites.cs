using UnityEngine;

/// <summary>
/// Calcula los bordes de la pantalla a partir de la cámara ortográfica.
/// Así el jugador, el enjambre y el UFO saben hasta dónde pueden moverse.
/// </summary>
public static class Limites
{
    /// <summary>Pequeño margen para que nada quede pegado al borde.</summary>
    public const float Margen = 0.3f;

    /// <summary>Mitad de la altura visible (en unidades del mundo).</summary>
    public static float MitadAlto
    {
        get { return Camera.main != null ? Camera.main.orthographicSize : 5f; }
    }

    /// <summary>Mitad del ancho visible (en unidades del mundo).</summary>
    public static float MitadAncho
    {
        get { return Camera.main != null ? Camera.main.orthographicSize * Camera.main.aspect : 8.9f; }
    }

    /// <summary>Borde lateral de la pantalla (menos el margen).</summary>
    public static float X
    {
        get { return MitadAncho - Margen; }
    }
}

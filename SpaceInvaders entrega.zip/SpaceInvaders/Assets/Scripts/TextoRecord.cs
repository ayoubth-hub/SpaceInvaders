using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Muestra en el menú la mejor puntuación guardada.
/// </summary>
[RequireComponent(typeof(Text))]
public class TextoRecord : MonoBehaviour
{
    void Start()
    {
        int record = PlayerPrefs.GetInt("Record", 0);
        GetComponent<Text>().text = "RÉCORD: " + record.ToString("0000");
    }
}

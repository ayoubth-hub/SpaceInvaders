using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// HERRAMIENTA DE EDITOR (no forma parte del juego).
///
/// La primera vez que abres el proyecto en Unity, este script:
///   1. Configura los sprites (tipo Sprite, filtro Point, 32 píxeles por unidad).
///   2. Crea los prefabs en Assets/Prefabs.
///   3. Crea las escenas Menu y SpaceInvaders en Assets/Scenes.
///   4. Añade las dos escenas a File > Build Profiles (Build Settings).
///
/// Si algún día quieres regenerarlo todo: menú "Space Invaders > Reconstruir escenas y prefabs".
/// Cuando ya tengas las escenas, puedes borrar la carpeta Assets/Editor si quieres.
/// </summary>
[InitializeOnLoad]
public static class ConstructorProyecto
{
    private const string CarpetaSprites = "Assets/Sprites";
    private const string CarpetaPrefabs = "Assets/Prefabs";
    private const string CarpetaEscenas = "Assets/Scenes";
    private const string RutaMenu = "Assets/Scenes/Menu.unity";
    private const string RutaJuego = "Assets/Scenes/SpaceInvaders.unity";
    private const float PixelesPorUnidad = 32f;

    private static Material materialSprites; // solo se usa si el proyecto tiene URP
    private static Font fuente;

    private class Prefabs
    {
        public GameObject jugador;
        public GameObject escudo;
        public Alien alienA;
        public Alien alienB;
        public Alien alienC;
        public Ufo ufo;
    }

    // ------------------------------------------------------------------
    // Arranque automático
    // ------------------------------------------------------------------

    private static double inicioEspera = -1;

    static ConstructorProyecto()
    {
        if (File.Exists(RutaMenu) && File.Exists(RutaJuego)) return;
        EditorApplication.update += EsperarYConstruir;
    }

    /// <summary>
    /// Espera a que Unity termine de importar y compilar (y un par de segundos más)
    /// antes de crear las escenas, para no interferir con el arranque del editor.
    /// </summary>
    private static void EsperarYConstruir()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            EditorApplication.update -= EsperarYConstruir;
            return;
        }
        if (EditorApplication.isCompiling || EditorApplication.isUpdating) return;

        if (inicioEspera < 0) inicioEspera = EditorApplication.timeSinceStartup;
        if (EditorApplication.timeSinceStartup - inicioEspera < 2.0) return;

        EditorApplication.update -= EsperarYConstruir;
        if (File.Exists(RutaMenu) && File.Exists(RutaJuego)) return;

        try
        {
            Construir();
        }
        catch (System.Exception e)
        {
            Debug.LogException(e);
            EditorUtility.DisplayDialog("Space Invaders",
                "No se han podido crear las escenas automáticamente.\n\n" +
                "Usa el menú Space Invaders > Reconstruir escenas y prefabs.", "OK");
        }
    }

    [MenuItem("Space Invaders/Reconstruir escenas y prefabs")]
    private static void ConstruirDesdeMenu()
    {
        bool aceptar = EditorUtility.DisplayDialog(
            "Space Invaders",
            "Se volverán a crear las escenas Menu y SpaceInvaders y todos los prefabs.\n" +
            "Los cambios que hayas hecho a mano en ellos se perderán.\n\n¿Continuar?",
            "Sí", "Cancelar");
        if (!aceptar) return;
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        Construir();
    }

    public static void Construir()
    {
        try
        {
            EditorUtility.DisplayProgressBar("Space Invaders", "Configurando sprites...", 0.1f);
            ConfigurarSprites();
            PrepararRecursos();
            CrearCarpeta(CarpetaPrefabs);
            CrearCarpeta(CarpetaEscenas);

            EditorUtility.DisplayProgressBar("Space Invaders", "Creando prefabs...", 0.4f);
            EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            Prefabs prefabs = CrearPrefabs();

            EditorUtility.DisplayProgressBar("Space Invaders", "Creando escenas...", 0.7f);
            CrearEscenaJuego(prefabs);
            CrearEscenaMenu();

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(RutaMenu, true),
                new EditorBuildSettingsScene(RutaJuego, true)
            };
            AssetDatabase.SaveAssets();

            EditorSceneManager.OpenScene(RutaMenu);
            Debug.Log("Space Invaders: escenas y prefabs creados. Abre Assets/Scenes/Menu y pulsa Play.");
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }
    }

    // ------------------------------------------------------------------
    // Sprites y recursos
    // ------------------------------------------------------------------

    private static void ConfigurarSprites()
    {
        EditorSettings.defaultBehaviorMode = EditorBehaviorMode.Mode2D;

        foreach (string guid in AssetDatabase.FindAssets("t:Texture2D", new[] { CarpetaSprites }))
        {
            string ruta = AssetDatabase.GUIDToAssetPath(guid);
            TextureImporter importador = AssetImporter.GetAtPath(ruta) as TextureImporter;
            if (importador == null) continue;

            bool yaConfigurado =
                importador.textureType == TextureImporterType.Sprite &&
                importador.spriteImportMode == SpriteImportMode.Single &&
                Mathf.Approximately(importador.spritePixelsPerUnit, PixelesPorUnidad) &&
                importador.filterMode == FilterMode.Point &&
                importador.textureCompression == TextureImporterCompression.Uncompressed &&
                !importador.mipmapEnabled;
            if (yaConfigurado) continue;

            importador.textureType = TextureImporterType.Sprite;
            importador.spriteImportMode = SpriteImportMode.Single;
            importador.spritePixelsPerUnit = PixelesPorUnidad;
            importador.filterMode = FilterMode.Point;            // píxeles nítidos, sin difuminar
            importador.textureCompression = TextureImporterCompression.Uncompressed;
            importador.mipmapEnabled = false;
            importador.alphaIsTransparency = true;
            importador.SaveAndReimport();
        }
    }

    private static void PrepararRecursos()
    {
        fuente = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        // Si el proyecto usa URP (plantilla Universal 2D), usamos el material "Unlit"
        // para que los sprites se vean sin necesidad de luces 2D.
        materialSprites = null;
        if (GraphicsSettings.currentRenderPipeline != null)
        {
            materialSprites = AssetDatabase.LoadAssetAtPath<Material>(
                "Packages/com.unity.render-pipelines.universal/Runtime/Materials/Sprite-Unlit-Default.mat");
        }
    }

    private static Sprite CargarSprite(string rutaRelativa)
    {
        Sprite sprite = AssetDatabase.LoadAssetAtPath<Sprite>(CarpetaSprites + "/" + rutaRelativa);
        if (sprite == null)
        {
            Debug.LogError("Space Invaders: no se encuentra el sprite " + CarpetaSprites + "/" + rutaRelativa);
        }
        return sprite;
    }

    private static void CrearCarpeta(string ruta)
    {
        if (AssetDatabase.IsValidFolder(ruta)) return;
        string padre = Path.GetDirectoryName(ruta).Replace('\\', '/');
        AssetDatabase.CreateFolder(padre, Path.GetFileName(ruta));
    }

    // ------------------------------------------------------------------
    // Prefabs
    // ------------------------------------------------------------------

    private static Prefabs CrearPrefabs()
    {
        Prefabs p = new Prefabs();

        // Explosión de alien
        GameObject explosion = CrearObjetoSprite("ExplosionAlien", CargarSprite("Invaders/space__0009_EnemyExplosion.png"), 5);
        explosion.AddComponent<Explosion>();
        GameObject prefabExplosion = GuardarPrefab(explosion);

        // Misiles de los aliens (uno por tipo, cada uno con sus 4 frames)
        MisilAlien misilA = CrearMisil("MisilA", "ProjectileA_1.png", "ProjectileA__2.png", "ProjectileA_3.png", "ProjectileA_4.png");
        MisilAlien misilB = CrearMisil("MisilB", "ProjectileB_1.png", "ProjectileB_2.png", "ProjectileB_3.png", "ProjectileB_4.png");
        MisilAlien misilC = CrearMisil("MisilC", "ProjectileC_1.png", "ProjectileC_2.png", "ProjectileC_3.png", "ProjectileC_4.png");

        // Bala del jugador: Rigidbody2D dinámico + collider Trigger
        GameObject bala = CrearObjetoSprite("BalaJugador", CargarSprite("Projectiles/Projectile_Player.png"), 3);
        AnadirRigidbody(bala, RigidbodyType2D.Dynamic).collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        AnadirCollider(bala, true);
        bala.AddComponent<BalaJugador>();
        BalaJugador prefabBala = GuardarPrefab(bala).GetComponent<BalaJugador>();

        // Aliens
        p.alienA = CrearAlien("AlienA", TipoAlien.A, 10, "space__0000_A1.png", "space__0001_A2.png", prefabExplosion, misilA);
        p.alienB = CrearAlien("AlienB", TipoAlien.B, 20, "space__0002_B1.png", "space__0003_B2.png", prefabExplosion, misilB);
        p.alienC = CrearAlien("AlienC", TipoAlien.C, 30, "space__0004_C1.png", "space__0005_C2.png", prefabExplosion, misilC);

        // UFO
        GameObject ufo = CrearObjetoSprite("UFO", CargarSprite("Invaders/space__0007_UFO.png"), 1);
        AnadirRigidbody(ufo, RigidbodyType2D.Kinematic);
        AnadirCollider(ufo, false);
        Ufo componenteUfo = ufo.AddComponent<Ufo>();
        componenteUfo.spriteExplosion = CargarSprite("Invaders/space__0009_EnemyExplosion.png");        p.ufo = GuardarPrefab(ufo).GetComponent<Ufo>();

        // Escudo
        GameObject escudo = CrearObjetoSprite("Escudo", CargarSprite("Invaders/space__0008_ShieldFull.png"), 0);
        AnadirCollider(escudo, false);
        escudo.AddComponent<Escudo>();
        p.escudo = GuardarPrefab(escudo);

        // Jugador
        GameObject jugador = CrearObjetoSprite("Jugador", CargarSprite("Invaders/space__0006_Player.png"), 2);
        AnadirRigidbody(jugador, RigidbodyType2D.Kinematic);
        AnadirCollider(jugador, false);
        Jugador componenteJugador = jugador.AddComponent<Jugador>();
        componenteJugador.prefabBala = prefabBala;
        componenteJugador.spriteExplosion = CargarSprite("Invaders/space__0010_PlayerExplosion.png");
        p.jugador = GuardarPrefab(jugador);

        return p;
    }

    private static MisilAlien CrearMisil(string nombre, params string[] archivos)
    {
        Sprite[] frames = new Sprite[archivos.Length];
        for (int i = 0; i < archivos.Length; i++)
        {
            frames[i] = CargarSprite("Projectiles/" + archivos[i]);
        }

        // Rigidbody2D dinámico + collider normal: los choques llegan por OnCollisionEnter2D
        GameObject go = CrearObjetoSprite(nombre, frames[0], 3);
        AnadirRigidbody(go, RigidbodyType2D.Dynamic).collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        AnadirCollider(go, false);
        MisilAlien misil = go.AddComponent<MisilAlien>();
        misil.frames = frames;
        return GuardarPrefab(go).GetComponent<MisilAlien>();
    }

    private static Alien CrearAlien(string nombre, TipoAlien tipo, int puntos, string frame1, string frame2,
                                    GameObject explosion, MisilAlien misil)
    {
        Sprite sprite1 = CargarSprite("Invaders/" + frame1);
        Sprite sprite2 = CargarSprite("Invaders/" + frame2);

        GameObject go = CrearObjetoSprite(nombre, sprite1, 1);
        AnadirRigidbody(go, RigidbodyType2D.Kinematic);
        AnadirCollider(go, false);

        Alien alien = go.AddComponent<Alien>();
        alien.tipo = tipo;
        alien.puntos = puntos;
        alien.frame1 = sprite1;
        alien.frame2 = sprite2;
        alien.prefabExplosion = explosion;
        alien.prefabMisil = misil;
        return GuardarPrefab(go).GetComponent<Alien>();
    }

    private static GameObject CrearObjetoSprite(string nombre, Sprite sprite, int orden)
    {
        GameObject go = new GameObject(nombre);
        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        sr.sortingOrder = orden;
        if (materialSprites != null) sr.sharedMaterial = materialSprites;
        return go;
    }

    private static Rigidbody2D AnadirRigidbody(GameObject go, RigidbodyType2D tipo)
    {
        Rigidbody2D rb = go.AddComponent<Rigidbody2D>();
        rb.bodyType = tipo;
        rb.gravityScale = 0f;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        return rb;
    }

    private static BoxCollider2D AnadirCollider(GameObject go, bool esTrigger)
    {
        BoxCollider2D col = go.AddComponent<BoxCollider2D>();
        Sprite sprite = go.GetComponent<SpriteRenderer>().sprite;
        if (sprite != null)
        {
            col.size = sprite.bounds.size;
            col.offset = sprite.bounds.center;
        }
        col.isTrigger = esTrigger;
        return col;
    }

    private static GameObject GuardarPrefab(GameObject go)
    {
        string ruta = CarpetaPrefabs + "/" + go.name + ".prefab";
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(go, ruta);
        Object.DestroyImmediate(go);
        return prefab;
    }

    // ------------------------------------------------------------------
    // Escena de juego
    // ------------------------------------------------------------------

    private static void CrearEscenaJuego(Prefabs p)
    {
        Scene escena = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        CrearCamara(Color.black);

        // Jugador
        GameObject jugador = (GameObject)PrefabUtility.InstantiatePrefab(p.jugador);
        jugador.transform.position = new Vector3(0f, -3.9f, 0f);

        // Escudos
        const float alturaEscudos = -2.6f;
        float[] posicionesX = { -4.5f, -1.5f, 1.5f, 4.5f };
        GameObject escudos = new GameObject("Escudos");
        for (int i = 0; i < posicionesX.Length; i++)
        {
            GameObject escudo = (GameObject)PrefabUtility.InstantiatePrefab(p.escudo, escudos.transform);
            escudo.transform.position = new Vector3(posicionesX[i], alturaEscudos, 0f);
            escudo.name = "Escudo_" + (i + 1);
        }
        float bordeSuperiorEscudos = alturaEscudos + p.escudo.GetComponent<SpriteRenderer>().sprite.bounds.extents.y;

        // Enjambre (los aliens se instancian al darle a Play)
        GameObject objetoEnjambre = new GameObject("Enjambre");
        objetoEnjambre.transform.position = new Vector3(0f, 3.6f, 0f);
        Enjambre enjambre = objetoEnjambre.AddComponent<Enjambre>();
        enjambre.prefabAlienA = p.alienA;
        enjambre.prefabAlienB = p.alienB;
        enjambre.prefabAlienC = p.alienC;
        enjambre.limiteInferior = bordeSuperiorEscudos;
        enjambre.jugador = jugador.GetComponent<Jugador>();

        // Generador del UFO
        GeneradorUfo generador = new GameObject("GeneradorUFO").AddComponent<GeneradorUfo>();
        generador.prefabUfo = p.ufo;

        // Interfaz
        Canvas canvas = CrearCanvas();
        Text textoPuntos = CrearTexto(canvas.transform, "TextoPuntos", "PUNTOS: 0000", 56, TextAnchor.UpperLeft,
                                      new Vector2(0f, 1f), new Vector2(30f, -20f), new Vector2(700f, 80f));
        Text textoVidas = CrearTexto(canvas.transform, "TextoVidas", "VIDAS: 3", 56, TextAnchor.LowerLeft,
                                     new Vector2(0f, 0f), new Vector2(30f, 20f), new Vector2(700f, 80f));

        GameObject panelFin = CrearPanel(canvas.transform, "PanelFin", new Color(0f, 0f, 0f, 0.8f));
        Vector2 centro = new Vector2(0.5f, 0.5f);
        Text titulo = CrearTexto(panelFin.transform, "Titulo", "GAME OVER", 130, TextAnchor.MiddleCenter,
                                 centro, new Vector2(0f, 270f), new Vector2(1600f, 180f));
        titulo.fontStyle = FontStyle.Bold;
        Text resumen = CrearTexto(panelFin.transform, "Resumen", "", 44, TextAnchor.MiddleCenter,
                                  centro, new Vector2(0f, 10f), new Vector2(1600f, 340f));
        Button botonReintentar = CrearBoton(panelFin.transform, "BotonReintentar", "REINTENTAR",
                                            new Vector2(-230f, -260f), new Vector2(400f, 100f));
        Button botonMenu = CrearBoton(panelFin.transform, "BotonMenu", "MENÚ",
                                      new Vector2(230f, -260f), new Vector2(400f, 100f));

        CrearEventSystem();

        // GameManager
        GameManager gm = new GameObject("GameManager").AddComponent<GameManager>();
        gm.textoPuntos = textoPuntos;
        gm.textoVidas = textoVidas;
        gm.panelFin = panelFin;
        gm.textoTituloFin = titulo;
        gm.textoResumenFin = resumen;

        // Botones -> métodos del GameManager (quedan visibles en el Inspector, en On Click)
        UnityEventTools.AddPersistentListener(botonReintentar.onClick, gm.Reiniciar);
        UnityEventTools.AddPersistentListener(botonMenu.onClick, gm.IrAlMenu);

        panelFin.SetActive(false);
        EditorSceneManager.SaveScene(escena, RutaJuego);
    }

    // ------------------------------------------------------------------
    // Escena de menú
    // ------------------------------------------------------------------

    private static void CrearEscenaMenu()
    {
        Scene escena = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        CrearCamara(new Color32(49, 77, 121, 255)); // azul por defecto de Unity, como en el vídeo

        Canvas canvas = CrearCanvas();
        Vector2 centro = new Vector2(0.5f, 0.5f);

        Text titulo = CrearTexto(canvas.transform, "Titulo", "SPACE INVADERS", 130, TextAnchor.MiddleCenter,
                                 centro, new Vector2(0f, 340f), new Vector2(1700f, 180f));
        titulo.fontStyle = FontStyle.Bold;

        Button botonJugar = CrearBoton(canvas.transform, "BotonJugar", "JUGAR",
                                       new Vector2(0f, 140f), new Vector2(420f, 100f));

        // Tabla de puntuaciones
        CrearFilaTabla(canvas.transform, CargarSprite("Invaders/space__0007_UFO.png"), "= 300 PUNTOS", -10f);
        CrearFilaTabla(canvas.transform, CargarSprite("Invaders/space__0004_C1.png"), "= 30 PUNTOS", -90f);
        CrearFilaTabla(canvas.transform, CargarSprite("Invaders/space__0002_B1.png"), "= 20 PUNTOS", -170f);
        CrearFilaTabla(canvas.transform, CargarSprite("Invaders/space__0000_A1.png"), "= 10 PUNTOS", -250f);

        Text record = CrearTexto(canvas.transform, "TextoRecord", "RÉCORD: 0000", 44, TextAnchor.MiddleCenter,
                                 centro, new Vector2(0f, -350f), new Vector2(800f, 60f));
        record.gameObject.AddComponent<TextoRecord>();

        Text ayuda = CrearTexto(canvas.transform, "TextoControles",
                                "FLECHAS o A/D: MOVER      ESPACIO: DISPARAR      ENTER: JUGAR", 30,
                                TextAnchor.MiddleCenter, centro, new Vector2(0f, -450f), new Vector2(1700f, 50f));
        ayuda.color = new Color(0.85f, 0.85f, 0.85f);

        CrearEventSystem();

        ControladorMenu controlador = new GameObject("SceneLoader").AddComponent<ControladorMenu>();
        UnityEventTools.AddPersistentListener(botonJugar.onClick, controlador.Jugar);

        EditorSceneManager.SaveScene(escena, RutaMenu);
    }

    private static void CrearFilaTabla(Transform padre, Sprite sprite, string texto, float y)
    {
        GameObject icono = new GameObject("Icono", typeof(RectTransform), typeof(Image));
        icono.layer = 5;
        icono.transform.SetParent(padre, false);
        RectTransform rt = (RectTransform)icono.transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = new Vector2(-150f, y);
        rt.sizeDelta = sprite != null ? new Vector2(sprite.rect.width * 3f, sprite.rect.height * 3f) : new Vector2(72f, 48f);
        Image imagen = icono.GetComponent<Image>();
        imagen.sprite = sprite;
        imagen.preserveAspect = true;
        imagen.raycastTarget = false;

        CrearTexto(padre, "TextoPuntos", texto, 44, TextAnchor.MiddleLeft,
                   new Vector2(0.5f, 0.5f), new Vector2(130f, y), new Vector2(360f, 60f));
    }

    // ------------------------------------------------------------------
    // Utilidades de escena e interfaz
    // ------------------------------------------------------------------

    private static Camera CrearCamara(Color fondo)
    {
        GameObject go = new GameObject("Main Camera");
        go.tag = "MainCamera";
        go.transform.position = new Vector3(0f, 0f, -10f);
        Camera camara = go.AddComponent<Camera>();
        camara.orthographic = true;
        camara.orthographicSize = 5f;
        camara.clearFlags = CameraClearFlags.SolidColor;
        camara.backgroundColor = fondo;
        go.AddComponent<AudioListener>();
        return camara;
    }

    private static Canvas CrearCanvas()
    {
        GameObject go = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.layer = 5;
        Canvas canvas = go.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler escalador = go.GetComponent<CanvasScaler>();
        escalador.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        escalador.referenceResolution = new Vector2(1920f, 1080f);
        escalador.matchWidthOrHeight = 1f;
        return canvas;
    }

    private static void CrearEventSystem()
    {
        GameObject go = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        go.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
        go.AddComponent<StandaloneInputModule>();
#endif
    }

    private static Text CrearTexto(Transform padre, string nombre, string contenido, int tamano, TextAnchor alineacion,
                                   Vector2 ancla, Vector2 posicion, Vector2 dimensiones)
    {
        GameObject go = new GameObject(nombre, typeof(RectTransform), typeof(Text));
        go.layer = 5;
        go.transform.SetParent(padre, false);

        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = ancla;
        rt.anchorMax = ancla;
        rt.pivot = ancla;
        rt.anchoredPosition = posicion;
        rt.sizeDelta = dimensiones;

        Text texto = go.GetComponent<Text>();
        texto.font = fuente;
        texto.fontSize = tamano;
        texto.alignment = alineacion;
        texto.color = Color.white;
        texto.text = contenido;
        texto.raycastTarget = false;
        texto.horizontalOverflow = HorizontalWrapMode.Overflow;
        texto.verticalOverflow = VerticalWrapMode.Overflow;
        return texto;
    }

    private static GameObject CrearPanel(Transform padre, string nombre, Color color)
    {
        GameObject go = new GameObject(nombre, typeof(RectTransform), typeof(Image));
        go.layer = 5;
        go.transform.SetParent(padre, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        go.GetComponent<Image>().color = color;
        return go;
    }

    private static Button CrearBoton(Transform padre, string nombre, string texto, Vector2 posicion, Vector2 dimensiones)
    {
        GameObject go = new GameObject(nombre, typeof(RectTransform), typeof(Image), typeof(Button));
        go.layer = 5;
        go.transform.SetParent(padre, false);
        RectTransform rt = (RectTransform)go.transform;
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = posicion;
        rt.sizeDelta = dimensiones;

        Image imagen = go.GetComponent<Image>();
        imagen.sprite = AssetDatabase.GetBuiltinExtraResource<Sprite>("UI/Skin/UISprite.psd");
        imagen.type = Image.Type.Sliced;
        imagen.color = Color.white;

        Button boton = go.GetComponent<Button>();
        boton.targetGraphic = imagen;
        ColorBlock colores = boton.colors;
        colores.highlightedColor = new Color(0.85f, 0.85f, 0.85f);
        colores.pressedColor = new Color(0.6f, 0.6f, 0.6f);
        boton.colors = colores;

        Text etiqueta = CrearTexto(go.transform, "Texto", texto, Mathf.RoundToInt(dimensiones.y * 0.5f),
                                   TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, dimensiones);
        etiqueta.color = Color.black;
        return boton;
    }
}

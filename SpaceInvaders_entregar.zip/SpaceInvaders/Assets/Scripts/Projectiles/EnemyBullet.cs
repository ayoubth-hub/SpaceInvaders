using UnityEngine;

/// <summary>
/// Bala enemiga. Cae hacia abajo.
/// Esta bala usa un Rigidbody2D DINÁMICO con un collider SÓLIDO (no trigger), y por eso:
///  - Contra el SUELO (collider sólido) se usa OnCollisionEnter2D.
///  - Contra el jugador y los escudos (colliders trigger) se usa OnTriggerEnter2D.
/// Su animación de 4 frames la hace el script SpriteAnimator del mismo prefab.
/// </summary>
public class EnemyBullet : MonoBehaviour
{
    [Tooltip("Velocidad hacia abajo (unidades/segundo)")]
    public float speed = 6f;

    bool used;

    void Start()
    {
        GetComponent<Rigidbody2D>().linearVelocity = Vector2.down * speed;
    }

    // Choque físico con un collider sólido: el suelo
    void OnCollisionEnter2D(Collision2D collision)
    {
        // Ignoramos el roce con otras balas enemigas
        if (collision.collider.GetComponent<EnemyBullet>() != null) return;
        Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Procesar(other);
    }

    // Stay: por si atraviesa un agujero del escudo y vuelve a tocar un trozo sólido
    void OnTriggerStay2D(Collider2D other)
    {
        Procesar(other);
    }

    void Procesar(Collider2D other)
    {
        if (used) return;

        // ¿Es el jugador?
        PlayerController player = other.GetComponent<PlayerController>();
        if (player != null)
        {
            // Hit() devuelve false si el jugador es invulnerable: en ese caso la bala lo atraviesa
            if (player.Hit())
            {
                used = true;
                Destroy(gameObject);
            }
            return;
        }

        // ¿Es un escudo? Miramos el punto de la parte delantera (abajo) de la bala
        Shield shield = other.GetComponent<Shield>();
        if (shield != null)
        {
            Vector2 punta = (Vector2)transform.position + Vector2.down * 0.2f;
            if (shield.TryDamage(punta))
            {
                used = true;
                Destroy(gameObject);
            }
        }
    }
}

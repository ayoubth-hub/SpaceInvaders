using UnityEngine;

/// <summary>
/// Bala del jugador. Sube en línea recta y se destruye al impactar con un alien, el UFO o un escudo,
/// o al salir por la parte superior de la pantalla.
/// Tiene Rigidbody2D (Kinematic) y un Collider2D con "Is Trigger" activado, por eso usamos OnTriggerEnter2D.
/// </summary>
public class PlayerBullet : MonoBehaviour
{
    [Tooltip("Velocidad hacia arriba (unidades/segundo)")]
    public float speed = 14f;
    [Tooltip("Si la bala pasa de esta altura (Y), se destruye")]
    public float limitY = 8f;

    bool used;

    void Start()
    {
        // Movimiento con el Rigidbody2D (linearVelocity es la API de Unity 6)
        GetComponent<Rigidbody2D>().linearVelocity = Vector2.up * speed;
    }

    void Update()
    {
        if (transform.position.y > limitY)
        {
            Destroy(gameObject);
        }
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        Procesar(other);
    }

    // Stay: por si la bala atraviesa un agujero del escudo y vuelve a tocar un trozo sólido
    void OnTriggerStay2D(Collider2D other)
    {
        Procesar(other);
    }

    void Procesar(Collider2D other)
    {
        if (used) return;

        // ¿Es un alien?
        Alien alien = other.GetComponent<Alien>();
        if (alien != null)
        {
            alien.Hit();
            Impacto();
            return;
        }

        // ¿Es el UFO?
        UFO ufo = other.GetComponent<UFO>();
        if (ufo != null)
        {
            ufo.Hit();
            Impacto();
            return;
        }

        // ¿Es un escudo? Miramos el punto de la parte delantera (arriba) de la bala
        Shield shield = other.GetComponent<Shield>();
        if (shield != null)
        {
            Vector2 punta = (Vector2)transform.position + Vector2.up * 0.2f;
            if (shield.TryDamage(punta)) Impacto();
        }
    }

    void Impacto()
    {
        used = true;
        Destroy(gameObject);
    }
}

using UnityEngine;

/// <summary>
/// Hace aparecer el UFO de vez en cuando (cada cierto tiempo aleatorio) por un lado de la pantalla.
/// Solo puede haber un UFO a la vez.
/// </summary>
public class UFOSpawner : MonoBehaviour
{
    [Tooltip("Prefab del UFO")]
    public GameObject ufoPrefab;
    [Tooltip("Tiempo mínimo entre apariciones (segundos)")]
    public float minDelay = 12f;
    [Tooltip("Tiempo máximo entre apariciones (segundos)")]
    public float maxDelay = 25f;
    [Tooltip("Altura (Y) por la que vuela el UFO")]
    public float spawnY = 6.6f;

    float timer;
    float nextDelay;
    Camera cam;

    void Start()
    {
        cam = Camera.main;
        nextDelay = Random.Range(minDelay, maxDelay);
    }

    void Update()
    {
        if (!GameManager.Instance.IsPlaying) return;

        timer += Time.deltaTime;
        if (timer >= nextDelay)
        {
            timer = 0f;
            nextDelay = Random.Range(minDelay, maxDelay);

            // Solo creamos uno si no hay ya otro en pantalla
            if (FindFirstObjectByType<UFO>() == null)
            {
                Aparecer();
            }
        }
    }

    void Aparecer()
    {
        // Elegimos al azar si entra por la izquierda o por la derecha
        bool desdeLaIzquierda = Random.value < 0.5f;
        float x = cam.orthographicSize * cam.aspect + 1.5f;
        if (desdeLaIzquierda) x = -x;

        GameObject go = Instantiate(ufoPrefab, new Vector3(x, spawnY, 0f), Quaternion.identity);
        go.GetComponent<UFO>().direction = desdeLaIzquierda ? 1 : -1;
    }
}

using UnityEngine;

/// <summary>
/// Nave bonus (UFO). Cruza la parte superior de la pantalla de un lado a otro.
/// Si la bala del jugador la destruye, da 300 puntos. Si llega al otro lado, desaparece.
/// La crea el UFOSpawner con Instantiate().
/// </summary>
public class UFO : MonoBehaviour
{
    [Tooltip("Velocidad horizontal")]
    public float speed = 4f;
    [Tooltip("Puntos que da al destruirlo")]
    public int points = 300;
    [Tooltip("Explosión al ser destruido")]
    public GameObject explosionPrefab;

    // 1 = se mueve a la derecha, -1 = a la izquierda (lo fija el UFOSpawner)
    [HideInInspector] public int direction = 1;

    Camera cam;
    bool dead;

    void Start()
    {
        cam = Camera.main;
    }

    void Update()
    {
        if (!GameManager.Instance.IsPlaying) return;

        transform.Translate(Vector3.right * direction * speed * Time.deltaTime);

        // Si sale por el lado contrario de la pantalla, se destruye
        float limite = cam.orthographicSize * cam.aspect + 3f;
        if (Mathf.Abs(transform.position.x) > limite)
        {
            Destroy(gameObject);
        }
    }

    /// <summary>La llama la bala del jugador.</summary>
    public void Hit()
    {
        if (dead || !GameManager.Instance.IsPlaying) return;
        dead = true;

        GameManager.Instance.AddScore(points);

        if (explosionPrefab != null)
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        }
        Destroy(gameObject);
    }
}

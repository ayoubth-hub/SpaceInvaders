using System.Collections;
using UnityEngine;

/// <summary>
/// Controla la nave del jugador:
///  - Movimiento horizontal con A/D o flechas, limitado a los bordes de la pantalla.
///  - Disparo con ESPACIO (solo una bala a la vez, como en el original).
///  - Al ser alcanzada: explosión, pierde una vida y reaparece pasados unos segundos.
/// Necesita en el mismo objeto: SpriteRenderer y Collider2D.
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Movimiento")]
    [Tooltip("Velocidad horizontal en unidades por segundo")]
    public float speed = 9f;

    [Header("Disparo")]
    [Tooltip("Prefab de la bala del jugador")]
    public GameObject bulletPrefab;
    [Tooltip("Punto (hijo de la nave) desde donde sale la bala")]
    public Transform firePoint;
    [Tooltip("Tiempo mínimo entre disparos")]
    public float fireCooldown = 0.35f;

    [Header("Vidas / reaparición")]
    [Tooltip("Prefab de la explosión de la nave")]
    public GameObject explosionPrefab;
    [Tooltip("Segundos que tarda en reaparecer tras explotar")]
    public float respawnDelay = 2f;
    [Tooltip("Segundos de invulnerabilidad (parpadeo) tras reaparecer")]
    public float invulnerableTime = 1.5f;

    SpriteRenderer sr;
    Collider2D col;
    Camera cam;
    Vector3 startPosition;
    GameObject currentBullet;   // Bala que está en pantalla (null si no hay ninguna)
    float nextFireTime;
    bool dead;
    bool invulnerable;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        col = GetComponent<Collider2D>();
        cam = Camera.main;
        startPosition = transform.position;
    }

    void Update()
    {
        // Si estamos muertos o la partida terminó, no hacemos nada
        if (dead || !GameManager.Instance.IsPlaying) return;

        Mover();
        Disparar();
    }

    void Mover()
    {
        float h = GameInput.Horizontal();
        Vector3 pos = transform.position;
        pos.x += h * speed * Time.deltaTime;

        // Límite de pantalla: mitad del ancho de la cámara menos la mitad de la nave
        float limite = cam.orthographicSize * cam.aspect - sr.sprite.bounds.extents.x;
        pos.x = Mathf.Clamp(pos.x, -limite, limite);

        transform.position = pos;
    }

    void Disparar()
    {
        // Solo disparamos si no hay otra bala viva y ha pasado el cooldown
        if (GameInput.FirePressed() && currentBullet == null && Time.time >= nextFireTime)
        {
            Vector3 origen = (firePoint != null) ? firePoint.position : transform.position + Vector3.up * 0.6f;
            currentBullet = Instantiate(bulletPrefab, origen, Quaternion.identity);
            nextFireTime = Time.time + fireCooldown;
        }
    }

    /// <summary>
    /// La llama la bala enemiga al tocar la nave.
    /// Devuelve true si el impacto cuenta (false si estamos muertos o invulnerables).
    /// </summary>
    public bool Hit()
    {
        if (dead || invulnerable || !GameManager.Instance.IsPlaying) return false;

        dead = true;

        // Explosión en la posición de la nave
        if (explosionPrefab != null)
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        }

        // Ocultamos la nave y desactivamos su collider
        sr.enabled = false;
        col.enabled = false;

        GameManager.Instance.LoseLife();

        // Si todavía quedan vidas, reaparecemos
        if (GameManager.Instance.IsPlaying)
        {
            StartCoroutine(Reaparecer());
        }
        return true;
    }

    IEnumerator Reaparecer()
    {
        yield return new WaitForSeconds(respawnDelay);

        transform.position = startPosition;
        sr.enabled = true;
        col.enabled = true;
        dead = false;

        // Invulnerabilidad con parpadeo
        invulnerable = true;
        float t = 0f;
        while (t < invulnerableTime)
        {
            sr.enabled = !sr.enabled;
            yield return new WaitForSeconds(0.1f);
            t += 0.1f;
        }
        sr.enabled = true;
        invulnerable = false;
    }
}

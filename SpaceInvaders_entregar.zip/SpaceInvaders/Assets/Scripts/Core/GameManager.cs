using System;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Estados posibles de la partida.
/// </summary>
public enum GameState
{
    Playing,   // Jugando
    GameOver,  // Derrota
    Victory    // Victoria
}

/// <summary>
/// Controla el estado global del juego: puntuación, vidas, Game Over, Victoria y reinicio.
/// Solo hay UN GameManager en la escena y el resto de scripts lo localizan con GameManager.Instance.
/// Avisa a otros scripts (por ejemplo, la interfaz) mediante EVENTOS de C#.
/// </summary>
public class GameManager : MonoBehaviour
{
    // Referencia estática para acceder al GameManager desde cualquier script.
    public static GameManager Instance { get; private set; }

    [Header("Configuración")]
    [Tooltip("Vidas con las que empieza el jugador")]
    public int startingLives = 3;

    // Estado actual (solo lectura desde fuera)
    public GameState State { get; private set; }
    public int Score { get; private set; }
    public int Lives { get; private set; }

    /// <summary>True si la partida está en marcha (ni Game Over ni Victoria).</summary>
    public bool IsPlaying
    {
        get { return State == GameState.Playing; }
    }

    // EVENTOS: otros scripts se suscriben para enterarse de los cambios.
    public event Action<int> OnScoreChanged;
    public event Action<int> OnLivesChanged;
    public event Action<GameState> OnGameStateChanged;

    void Awake()
    {
        Instance = this;
        State = GameState.Playing;
        Score = 0;
        Lives = startingLives;
        Time.timeScale = 1f;
    }

    void Update()
    {
        // Cuando la partida ha terminado, ENTER o R reinician.
        if (!IsPlaying && GameInput.RestartPressed())
        {
            Restart();
        }
    }

    /// <summary>Suma puntos (la llaman los aliens y el UFO al ser destruidos).</summary>
    public void AddScore(int points)
    {
        if (!IsPlaying) return;
        Score += points;
        if (OnScoreChanged != null) OnScoreChanged(Score);
    }

    /// <summary>Resta una vida (la llama el jugador al ser alcanzado). Con 0 vidas: Game Over.</summary>
    public void LoseLife()
    {
        if (!IsPlaying) return;
        Lives--;
        if (Lives < 0) Lives = 0;
        if (OnLivesChanged != null) OnLivesChanged(Lives);
        if (Lives <= 0) EndGame(GameState.GameOver);
    }

    /// <summary>La llama el enjambre cuando un alien llega a la altura de los escudos / suelo.</summary>
    public void AliensReachedShields()
    {
        EndGame(GameState.GameOver);
    }

    /// <summary>La llama el enjambre cuando no queda ningún alien.</summary>
    public void AllAliensDestroyed()
    {
        EndGame(GameState.Victory);
    }

    void EndGame(GameState newState)
    {
        if (!IsPlaying) return; // Si ya terminó, no hacemos nada
        State = newState;
        if (OnGameStateChanged != null) OnGameStateChanged(State);
    }

    /// <summary>Reinicia la partida recargando la escena actual.</summary>
    public void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}

using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Clase auxiliar que lee el teclado.
/// Funciona tanto si el proyecto usa el nuevo Input System (Unity 6 por defecto)
/// como si usa el Input Manager clásico. Así el resto de scripts no se preocupan
/// de qué sistema de entrada está activo.
/// </summary>
public static class GameInput
{
    /// <summary>-1 = izquierda (flecha izq. o A), +1 = derecha (flecha der. o D), 0 = quieto.</summary>
    public static float Horizontal()
    {
        float h = 0f;
#if ENABLE_INPUT_SYSTEM
        Keyboard kb = Keyboard.current;
        if (kb != null)
        {
            if (kb.leftArrowKey.isPressed || kb.aKey.isPressed) h -= 1f;
            if (kb.rightArrowKey.isPressed || kb.dKey.isPressed) h += 1f;
        }
#else
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) h -= 1f;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) h += 1f;
#endif
        return h;
    }

    /// <summary>True mientras se mantiene pulsada la tecla ESPACIO.</summary>
    public static bool FirePressed()
    {
#if ENABLE_INPUT_SYSTEM
        Keyboard kb = Keyboard.current;
        return kb != null && kb.spaceKey.isPressed;
#else
        return Input.GetKey(KeyCode.Space);
#endif
    }

    /// <summary>True el frame en que se pulsa ENTER o R (para reiniciar la partida).</summary>
    public static bool RestartPressed()
    {
#if ENABLE_INPUT_SYSTEM
        Keyboard kb = Keyboard.current;
        return kb != null && (kb.enterKey.wasPressedThisFrame || kb.numpadEnterKey.wasPressedThisFrame || kb.rKey.wasPressedThisFrame);
#else
        return Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetKeyDown(KeyCode.R);
#endif
    }
}

using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Muestra en pantalla la puntuación, las vidas y los mensajes de GAME OVER / VICTORIA.
/// Se suscribe a los eventos del GameManager, así que no necesita un Update().
/// Los textos se asignan desde el Inspector (están en el Canvas de la escena).
/// Si alguno faltara, el script crea una interfaz de emergencia por código.
/// </summary>
public class UIManager : MonoBehaviour
{
    [Header("Textos de la interfaz (Canvas)")]
    public Text scoreText;
    public Text livesText;
    public Text messageText;
    public Text hintText;

    void Start()
    {
        if (scoreText == null || livesText == null || messageText == null || hintText == null)
        {
            CrearInterfazDeEmergencia();
        }
        AsignarFuentes();

        GameManager gm = GameManager.Instance;

        // Nos suscribimos a los eventos del GameManager
        gm.OnScoreChanged += ActualizarPuntos;
        gm.OnLivesChanged += ActualizarVidas;
        gm.OnGameStateChanged += MostrarEstado;

        // Valores iniciales
        ActualizarPuntos(gm.Score);
        ActualizarVidas(gm.Lives);
        messageText.text = "";
        hintText.text = "";
    }

    void OnDestroy()
    {
        // Nos damos de baja de los eventos para no dejar referencias colgando
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnScoreChanged -= ActualizarPuntos;
            GameManager.Instance.OnLivesChanged -= ActualizarVidas;
            GameManager.Instance.OnGameStateChanged -= MostrarEstado;
        }
    }

    void ActualizarPuntos(int puntos)
    {
        scoreText.text = "PUNTOS: " + puntos.ToString("0000");
    }

    void ActualizarVidas(int vidas)
    {
        livesText.text = "VIDAS: " + vidas;
    }

    void MostrarEstado(GameState estado)
    {
        if (estado == GameState.GameOver)
        {
            messageText.text = "GAME OVER";
            messageText.color = new Color(1f, 0.25f, 0.25f);
        }
        else if (estado == GameState.Victory)
        {
            messageText.text = "¡VICTORIA!";
            messageText.color = new Color(0.3f, 1f, 0.3f);
        }
        hintText.text = "Pulsa ENTER para reiniciar";
    }

    // Si algún Text no tiene fuente, usamos la fuente integrada de Unity.
    void AsignarFuentes()
    {
        Font fuente = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        Text[] textos = { scoreText, livesText, messageText, hintText };
        foreach (Text t in textos)
        {
            if (t != null && t.font == null) t.font = fuente;
        }
    }

    // ---- Interfaz de emergencia (solo se usa si faltan referencias en el Inspector) ----
    void CrearInterfazDeEmergencia()
    {
        GameObject canvasGO = new GameObject("Canvas (auto)");
        Canvas canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1280f, 720f);

        if (scoreText == null)
            scoreText = CrearTexto(canvasGO.transform, "ScoreText", new Vector2(0f, 1f), new Vector2(20f, -20f), 32, TextAnchor.UpperLeft);
        if (livesText == null)
            livesText = CrearTexto(canvasGO.transform, "LivesText", new Vector2(1f, 1f), new Vector2(-20f, -20f), 32, TextAnchor.UpperRight);
        if (messageText == null)
            messageText = CrearTexto(canvasGO.transform, "MessageText", new Vector2(0.5f, 0.5f), new Vector2(0f, 40f), 90, TextAnchor.MiddleCenter);
        if (hintText == null)
            hintText = CrearTexto(canvasGO.transform, "HintText", new Vector2(0.5f, 0.5f), new Vector2(0f, -60f), 34, TextAnchor.MiddleCenter);
    }

    Text CrearTexto(Transform padre, string nombre, Vector2 ancla, Vector2 posicion, int tamano, TextAnchor alineacion)
    {
        GameObject go = new GameObject(nombre);
        go.transform.SetParent(padre, false);
        Text t = go.AddComponent<Text>();
        RectTransform rt = t.rectTransform;
        rt.anchorMin = ancla;
        rt.anchorMax = ancla;
        rt.pivot = ancla;
        rt.anchoredPosition = posicion;
        rt.sizeDelta = new Vector2(700f, 120f);
        t.fontSize = tamano;
        t.alignment = alineacion;
        t.color = Color.white;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        return t;
    }
}

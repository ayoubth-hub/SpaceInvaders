using UnityEngine;

/// <summary>
/// Animación sencilla por frames: va cambiando el sprite del SpriteRenderer
/// entre los sprites de la lista "frames". La usan los disparos enemigos (4 frames).
/// </summary>
public class SpriteAnimator : MonoBehaviour
{
    [Tooltip("Sprites de la animación, en orden")]
    public Sprite[] frames;
    [Tooltip("Frames por segundo")]
    public float framesPerSecond = 10f;

    SpriteRenderer sr;
    float timer;
    int index;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        if (frames != null && frames.Length > 0) sr.sprite = frames[0];
    }

    void Update()
    {
        if (frames == null || frames.Length == 0) return;

        timer += Time.deltaTime;
        float duracionFrame = 1f / framesPerSecond;
        while (timer >= duracionFrame)
        {
            timer -= duracionFrame;
            index = (index + 1) % frames.Length;
            sr.sprite = frames[index];
        }
    }
}

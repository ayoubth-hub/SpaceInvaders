using UnityEngine;

/// <summary>
/// Explosión temporal: se destruye sola pasado "lifetime" segundos.
/// Opcionalmente parpadea (voltea el sprite) para dar sensación de animación.
/// La usan tanto la explosión de los aliens como la de la nave del jugador.
/// </summary>
public class Explosion : MonoBehaviour
{
    [Tooltip("Segundos que dura la explosión en pantalla")]
    public float lifetime = 0.3f;
    [Tooltip("Cada cuántos segundos voltea el sprite (0 = no parpadea)")]
    public float flickerInterval = 0f;

    SpriteRenderer sr;
    float timer;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        Destroy(gameObject, lifetime);
    }

    void Update()
    {
        if (flickerInterval <= 0f) return;

        timer += Time.deltaTime;
        if (timer >= flickerInterval)
        {
            timer = 0f;
            sr.flipX = !sr.flipX;
        }
    }
}

using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// El ENJAMBRE: crea la formación de aliens, los mueve todos juntos y los hace disparar.
///
///  - Formación: columns x rows aliens (mínimo 5x4). Fila superior = tipo C, filas intermedias = B,
///    filas inferiores = A.
///  - Movimiento por "pasos": cada cierto tiempo el enjambre se desplaza un poco hacia un lado.
///    Si el siguiente paso se saldría de la pantalla, baja una fila y cambia de dirección.
///  - Aceleración: el tiempo entre pasos depende de cuántos aliens quedan (menos aliens = más rápido).
///  - Animación: en cada paso todos los aliens cambian de sprite.
///  - Disparo: aleatorio; cuantos menos aliens queden, más frecuente.
///  - Game Over si algún alien baja hasta la línea de los escudos. Victoria si no queda ninguno.
/// </summary>
public class AlienSwarm : MonoBehaviour
{
    [Header("Prefabs de aliens")]
    public GameObject alienAPrefab;   // 10 puntos (filas inferiores)
    public GameObject alienBPrefab;   // 20 puntos (filas intermedias)
    public GameObject alienCPrefab;   // 30 puntos (fila superior)

    [Header("Formación")]
    [Min(5)] public int columns = 10;
    [Min(4)] public int rows = 5;
    [Tooltip("Separación horizontal entre aliens")]
    public float spacingX = 1.7f;
    [Tooltip("Separación vertical entre filas")]
    public float spacingY = 1.1f;
    [Tooltip("Altura (Y) de la fila superior al empezar")]
    public float startY = 5.4f;

    [Header("Movimiento")]
    [Tooltip("Distancia que avanza el enjambre en cada paso")]
    public float stepDistance = 0.3f;
    [Tooltip("Distancia que baja al llegar a un borde (una fila)")]
    public float dropDistance = 1.1f;
    [Tooltip("Segundos entre pasos con TODOS los aliens vivos (lento)")]
    public float slowStepTime = 0.55f;
    [Tooltip("Segundos entre pasos con UN solo alien vivo (rápido)")]
    public float fastStepTime = 0.03f;
    [Tooltip("Margen respecto al borde de la pantalla")]
    public float sideMargin = 0.4f;

    [Header("Disparo enemigo")]
    [Tooltip("Segundos entre disparos con todos los aliens vivos")]
    public float slowShootInterval = 1.4f;
    [Tooltip("Segundos entre disparos con muy pocos aliens")]
    public float fastShootInterval = 0.35f;
    [Tooltip("Máximo de balas enemigas a la vez en pantalla")]
    public int maxEnemyBullets = 3;

    [Header("Fin de partida")]
    [Tooltip("Si un alien baja de esta altura (Y) -> GAME OVER (altura de los escudos)")]
    public float invasionLineY = -3.0f;

    Alien[,] grid;          // grid[columna, fila]: null = alien muerto
    int totalAliens;
    int aliveAliens;
    int direction = 1;      // 1 = derecha, -1 = izquierda
    float stepTimer;
    float shootTimer;
    float nextShootDelay = 1f;
    Camera cam;

    void Start()
    {
        cam = Camera.main;
        CrearFormacion();
    }

    // ------------------------------------------------------------------
    // CREACIÓN DE LA FORMACIÓN (Instantiate)
    // ------------------------------------------------------------------
    void CrearFormacion()
    {
        grid = new Alien[columns, rows];
        float startX = -(columns - 1) * spacingX / 2f;   // Centrado en X

        for (int r = 0; r < rows; r++)
        {
            GameObject prefab = ElegirPrefab(r);
            for (int c = 0; c < columns; c++)
            {
                Vector3 pos = new Vector3(startX + c * spacingX, startY - r * spacingY, 0f);

                // Instantiate(prefab, posición, rotación, padre): los aliens son hijos del enjambre
                GameObject go = Instantiate(prefab, pos, Quaternion.identity, transform);
                go.name = prefab.name + "_" + c + "_" + r;

                Alien alien = go.GetComponent<Alien>();
                alien.swarm = this;
                alien.column = c;
                alien.row = r;
                grid[c, r] = alien;
            }
        }

        totalAliens = columns * rows;
        aliveAliens = totalAliens;
    }

    // Fila superior: C. Filas inferiores (la mitad de abajo): A. El resto: B.
    GameObject ElegirPrefab(int fila)
    {
        if (fila == 0) return alienCPrefab;
        if (fila >= rows - rows / 2) return alienAPrefab;
        return alienBPrefab;
    }

    // ------------------------------------------------------------------
    // BUCLE PRINCIPAL
    // ------------------------------------------------------------------
    void Update()
    {
        if (grid == null || aliveAliens <= 0) return;
        if (!GameManager.Instance.IsPlaying) return;

        // 0 = queda un alien, 1 = están todos vivos
        float proporcion = (float)aliveAliens / totalAliens;

        // ---- Movimiento por pasos (más rápido cuantos menos aliens quedan) ----
        float stepTime = Mathf.Lerp(fastStepTime, slowStepTime, proporcion);
        stepTimer += Time.deltaTime;
        if (stepTimer >= stepTime)
        {
            stepTimer = 0f;
            DarPaso();
        }

        // ---- Disparo aleatorio (más frecuente cuantos menos aliens quedan) ----
        shootTimer += Time.deltaTime;
        if (shootTimer >= nextShootDelay)
        {
            shootTimer = 0f;
            Disparar();
            float intervalo = Mathf.Lerp(fastShootInterval, slowShootInterval, proporcion);
            nextShootDelay = intervalo * Random.Range(0.6f, 1.4f);
        }
    }

    void DarPaso()
    {
        float minX, maxX, minY;
        ObtenerLimites(out minX, out maxX, out minY);

        // Borde de pantalla (según el tamaño de la cámara)
        float limite = cam.orthographicSize * cam.aspect - sideMargin;

        float siguienteMin = minX + direction * stepDistance;
        float siguienteMax = maxX + direction * stepDistance;
        bool llegaAlBorde = (direction > 0 && siguienteMax > limite) || (direction < 0 && siguienteMin < -limite);

        if (llegaAlBorde)
        {
            // Baja UNA fila y cambia de dirección
            transform.position += Vector3.down * dropDistance;
            direction = -direction;
        }
        else
        {
            transform.position += Vector3.right * direction * stepDistance;
        }

        // Animación: todos los aliens cambian de sprite en cada paso
        for (int c = 0; c < columns; c++)
        {
            for (int r = 0; r < rows; r++)
            {
                if (grid[c, r] != null) grid[c, r].ToggleFrame();
            }
        }

        // ¿Ha llegado algún alien a la altura de los escudos?
        ObtenerLimites(out minX, out maxX, out minY);
        if (minY <= invasionLineY)
        {
            GameManager.Instance.AliensReachedShields();
        }
    }

    // Calcula el rectángulo que ocupan los aliens vivos
    void ObtenerLimites(out float minX, out float maxX, out float minY)
    {
        minX = float.MaxValue;
        maxX = float.MinValue;
        minY = float.MaxValue;

        for (int c = 0; c < columns; c++)
        {
            for (int r = 0; r < rows; r++)
            {
                Alien a = grid[c, r];
                if (a == null) continue;
                Vector3 p = a.transform.position;
                minX = Mathf.Min(minX, p.x - a.HalfWidth);
                maxX = Mathf.Max(maxX, p.x + a.HalfWidth);
                minY = Mathf.Min(minY, p.y - a.HalfHeight);
            }
        }
    }

    // Elige al azar una columna que tenga aliens y dispara el alien MÁS BAJO de esa columna
    void Disparar()
    {
        // No hay más de maxEnemyBullets balas enemigas a la vez
        EnemyBullet[] balas = FindObjectsByType<EnemyBullet>(FindObjectsSortMode.None);
        if (balas.Length >= maxEnemyBullets) return;

        List<Alien> tiradores = new List<Alien>();
        for (int c = 0; c < columns; c++)
        {
            for (int r = rows - 1; r >= 0; r--)
            {
                if (grid[c, r] != null)
                {
                    tiradores.Add(grid[c, r]);
                    break; // solo el más bajo de la columna
                }
            }
        }

        if (tiradores.Count == 0) return;
        tiradores[Random.Range(0, tiradores.Count)].Shoot();
    }

    // ------------------------------------------------------------------
    // La llama cada Alien cuando muere
    // ------------------------------------------------------------------
    public void AlienDied(Alien alien)
    {
        grid[alien.column, alien.row] = null;
        aliveAliens--;

        if (aliveAliens <= 0)
        {
            GameManager.Instance.AllAliensDestroyed();
        }
    }
}

using UnityEngine;

/// <summary>
/// Un alien individual. Cada tipo (A, B, C) es un prefab distinto con distintos sprites y puntos.
/// El movimiento NO lo hace el alien: lo hace el enjambre (AlienSwarm), que es el padre de todos.
/// El alien solo sabe: cambiar de frame, disparar y morir cuando le alcanza una bala.
/// </summary>
public class Alien : MonoBehaviour
{
    [Header("Datos del alien")]
    [Tooltip("Puntos que da al destruirlo (A=10, B=20, C=30)")]
    public int points = 10;
    [Tooltip("Primer sprite de la animación")]
    public Sprite frame1;
    [Tooltip("Segundo sprite de la animación")]
    public Sprite frame2;

    [Header("Prefabs que utiliza")]
    [Tooltip("Bala que dispara este tipo de alien")]
    public GameObject bulletPrefab;
    [Tooltip("Explosión que aparece al morir")]
    public GameObject explosionPrefab;

    // El enjambre rellena estos datos al crear el alien (no hace falta tocarlos)
    [HideInInspector] public AlienSwarm swarm;
    [HideInInspector] public int column;
    [HideInInspector] public int row;

    SpriteRenderer sr;
    bool showingSecondFrame;
    bool dead;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    // Medidas del sprite en unidades de Unity (las usa el enjambre para detectar los bordes)
    public float HalfWidth
    {
        get { return sr.sprite.bounds.extents.x; }
    }

    public float HalfHeight
    {
        get { return sr.sprite.bounds.extents.y; }
    }

    /// <summary>Alterna entre el sprite 1 y el 2 (animación clásica). La llama el enjambre en cada paso.</summary>
    public void ToggleFrame()
    {
        showingSecondFrame = !showingSecondFrame;
        sr.sprite = showingSecondFrame ? frame2 : frame1;
    }

    /// <summary>Dispara una bala hacia abajo desde la parte inferior del alien.</summary>
    public void Shoot()
    {
        if (bulletPrefab == null) return;
        Vector3 origen = transform.position + Vector3.down * HalfHeight;
        Instantiate(bulletPrefab, origen, Quaternion.identity);
    }

    /// <summary>La llama la bala del jugador al tocar al alien.</summary>
    public void Hit()
    {
        if (dead || !GameManager.Instance.IsPlaying) return;
        dead = true;

        // Puntos
        GameManager.Instance.AddScore(points);

        // Explosión
        if (explosionPrefab != null)
        {
            Instantiate(explosionPrefab, transform.position, Quaternion.identity);
        }

        // Avisamos al enjambre para que nos quite de su lista y cuente los vivos
        if (swarm != null) swarm.AlienDied(this);

        Destroy(gameObject);
    }
}

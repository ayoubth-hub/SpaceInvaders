using UnityEngine;

/// <summary>
/// Escudo destructible. Cada impacto borra un pequeño "cráter" de píxeles del sprite,
/// así el escudo se va destruyendo progresivamente (tanto con balas enemigas como del jugador).
///
/// Para poder borrar píxeles, el sprite necesita tener activado "Read/Write" en su importador
/// (ya viene configurado en el proyecto). Si no estuviera activado, el escudo usa un
/// sistema alternativo: aguanta N impactos y se va oscureciendo hasta desaparecer.
///
/// Las balas llaman a TryDamage() con el punto donde están. Si ahí hay un píxel sólido, devuelve
/// true (impacto, la bala se destruye); si hay un hueco, devuelve false y la bala sigue su camino.
/// </summary>
public class Shield : MonoBehaviour
{
    [Header("Daño")]
    [Tooltip("Radio (en píxeles del sprite) del cráter que deja cada impacto")]
    public int craterRadius = 2;
    [Tooltip("Impactos que aguanta si no se puede borrar píxeles (modo alternativo)")]
    public int fallbackMaxHits = 8;

    SpriteRenderer sr;
    Texture2D tex;
    Color32[] pixels;
    int w;
    int h;
    float ppu;
    bool pixelMode;
    int hits;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        Sprite original = sr.sprite;
        Texture2D src = original.texture;

        if (src.isReadable)
        {
            // Hacemos una COPIA de la textura para no modificar el archivo original
            w = src.width;
            h = src.height;
            pixels = src.GetPixels32();
            tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            tex.filterMode = FilterMode.Point;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.SetPixels32(pixels);
            tex.Apply();

            ppu = original.pixelsPerUnit;
            sr.sprite = Sprite.Create(tex, new Rect(0f, 0f, w, h), new Vector2(0.5f, 0.5f), ppu);
            pixelMode = true;
        }
    }

    void OnDestroy()
    {
        if (tex != null) Destroy(tex);
    }

    /// <summary>
    /// Intenta dañar el escudo en un punto del mundo.
    /// Devuelve true si el escudo ha sido realmente golpeado.
    /// </summary>
    public bool TryDamage(Vector2 worldPoint)
    {
        if (!pixelMode)
        {
            return DanoAlternativo();
        }

        // Convertimos el punto del mundo a coordenadas de píxel de la textura
        Vector3 local = transform.InverseTransformPoint(worldPoint);
        int px = Mathf.FloorToInt(local.x * ppu + w / 2f);
        int py = Mathf.FloorToInt(local.y * ppu + h / 2f);

        // Fuera del sprite o píxel transparente (ya destruido): no hay impacto
        if (px < 0 || px >= w || py < 0 || py >= h) return false;
        if (pixels[py * w + px].a < 128) return false;

        // Borramos un círculo de píxeles alrededor del impacto
        int r = craterRadius;
        for (int dy = -r; dy <= r; dy++)
        {
            for (int dx = -r; dx <= r; dx++)
            {
                if (dx * dx + dy * dy > r * r + 1) continue;
                int nx = px + dx;
                int ny = py + dy;
                if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;
                pixels[ny * w + nx] = new Color32(0, 0, 0, 0);
            }
        }

        tex.SetPixels32(pixels);
        tex.Apply();
        return true;
    }

    // Modo alternativo: cada impacto lo oscurece; al llegar al máximo se destruye
    bool DanoAlternativo()
    {
        hits++;
        float brillo = 1f - (float)hits / fallbackMaxHits;
        Color c = sr.color;
        sr.color = new Color(c.r * brillo, c.g * brillo, c.b * brillo, 1f);
        if (hits >= fallbackMaxHits) Destroy(gameObject);
        return true;
    }
}
